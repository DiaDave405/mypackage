# mypackage
This library is a test of how to publish my own package.

# How to install

